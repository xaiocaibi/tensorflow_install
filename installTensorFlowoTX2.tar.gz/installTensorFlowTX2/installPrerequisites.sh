#!/bin/bash
# NVIDIA Jetson TX2
# Install TensorFlow dependencies and prerequisites
# Install Java and other dependencies by apt-get
./scripts/installDependencies.sh
./scripts/installBazel.sh


