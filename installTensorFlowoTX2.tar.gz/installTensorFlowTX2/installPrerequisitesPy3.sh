#!/bin/bash
# NVIDIA Jetson TX2
# Install TensorFlow dependencies and prerequisites
# Install Java and other dependencies by apt-get
./scripts/installDependenciesPy3.sh
./scripts/installBazel.sh


