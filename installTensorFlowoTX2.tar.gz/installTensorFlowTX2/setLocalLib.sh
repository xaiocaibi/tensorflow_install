#!/bin/bash
# NVIDIA Jetson TX2
# TensorFlow Installation
# Useful setup command to set library path
sudo sh -c 'echo /usr/local/lib >> /etc/ld.so.conf'
sudo ldconfig



